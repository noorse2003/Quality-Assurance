// Test case: Place order and checkout successfully
// This test validates the entire workflow of logging in, adding a product to the cart, and completing the checkout process.

describe("template spec", () => {
  it("passes", () => {
    // Step 1: Navigate to the homepage of the e-commerce application.
    // Purpose: Ensure the site is accessible and we start the test at the correct base URL.
    cy.visit("http://localhost:3000/");

    // Step 2: Initiate the login process by clicking the login button in the navigation bar.
    // Purpose: Users need to log in to perform actions like adding items to the cart and checking out.
    cy.get(
      '[style="border: white; background-color: white;"] > .nav-link'
    ).click();

    // Step 3: Clear and fill the email field with the user’s credentials.
    // Purpose: Input valid login credentials for authentication.
    cy.get(":nth-child(1) > input").clear("amna123@gmail.com"); // Clear any pre-filled value.
    cy.get(":nth-child(1) > input").type("amna123@gmail.com"); // Enter the email.

    // Step 4: Clear and fill the password field with the user’s credentials.
    // Purpose: Enter the user's password for login.
    cy.get(":nth-child(2) > input").clear("1"); // Clear any pre-filled value.
    cy.get(":nth-child(2) > input").type("1234"); // Enter the password.

    // Step 5: Submit the login form.
    // Purpose: Log in to the application and gain access to user-specific functionality (like cart and checkout).
    cy.get("form > button").click();

    // Step 6: Add a product to the cart.
    // Simulate the action of a customer browsing products and choosing one to purchase.

    // Click on the 'Add to Cart' button for the first product displayed on the homepage.
    cy.get(":nth-child(1) > .product-details > .btn").click();

    // Select a specific product option, such as the color "white."
    // Purpose: Ensure the correct product variation is added to the cart.
    cy.get("select").select("white");

    // Confirm the selected product options and add the item to the cart.
    // Purpose: Validate that the product is successfully added to the cart with the chosen options.
    cy.get(
      '[style="display: flex; align-items: center; margin-bottom: 20px;"] > button'
    ).click();

    // Step 7: Navigate to the cart page.
    // Purpose: Verify the selected items are present in the cart before proceeding to checkout.
    cy.get('[href="/cart"]').click();

    // Step 8: Click the checkout button to proceed to the checkout process.
    // Purpose: Begin the order placement workflow, transitioning from the cart to the checkout page.
    cy.get(".btn").click();

    // Step 9: Finalize the checkout process by clicking the confirmation button.
    // Purpose: Complete the order, validating the functionality of the checkout and order placement.
    cy.get(".btn").click();
  });
});
