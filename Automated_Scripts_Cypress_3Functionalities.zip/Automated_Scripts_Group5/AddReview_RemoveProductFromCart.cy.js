// Test case: Delete from cart and add a review
// This test validates two core functionalities:
// 1. Removing items from the cart.
// 2. Adding a review for a product.

describe("template spec", () => {
  it("passes", () => {
    // Step 1: Navigate to the homepage of the application.
    // Purpose: Start the test from the application's base URL to ensure consistency.
    cy.visit("http://localhost:3000/");

    // Step 2: User login process.
    // Purpose: Log in with a registered account to perform cart and review actions.
    cy.get(
      '[style="border: white; background-color: white;"] > .nav-link'
    ).click(); // Navigate to the login page.

    // Fill in the email field with the user's credentials.
    cy.get(":nth-child(1) > input").clear("amna123@gmail.com");
    cy.get(":nth-child(1) > input").type("amna123@gmail.com");

    // Fill in the password field with the user's credentials.
    cy.get(":nth-child(2) > input").clear("1");
    cy.get(":nth-child(2) > input").type("1234");

    // Submit the login form to authenticate.
    cy.get("form > button").click();

    // Step 3: Add a product to the cart.
    // Purpose: Select a product to interact with (e.g., review or delete).
    cy.get(":nth-child(4) > .product-details > .btn").click(); // Click the 'Add to Cart' button for the fourth product listed.

    // Step 4: Simulate adding a review for the product.
    // Purpose: Validate the product review functionality.

    // Click the input field for review multiple times (simulating user interaction).
    cy.get(
      '[style="display: flex; align-items: center; margin-bottom: 20px;"] > input'
    ).click(); // First interaction.
    cy.get(
      '[style="display: flex; align-items: center; margin-bottom: 20px;"] > input'
    ).click(); // Additional interactions.

    // Clear the review input field and enter a new review.
    cy.get(":nth-child(1) > input").clear("I");
    cy.get(":nth-child(1) > input").type("I like it"); // Enter the review text.

    // Submit the review form.
    cy.get("form > button").click();

    // Step 5: Navigate to the cart page.
    // Purpose: Validate the cart's content and interact with it.
    cy.get(
      '[style="display: flex; align-items: center; margin-bottom: 20px;"] > button'
    ).click(); // Confirm product addition.
    cy.get('[href="/cart"]').click(); // Go to the cart page.

    // Step 6: Delete items from the cart.
    // Purpose: Test the functionality of removing products from the cart.

    // Remove the first product from the cart (repeated multiple times to simulate bulk deletion or redundant interactions).
    cy.get(
      ':nth-child(1) > [style="padding: 12px 10px 12px 12px;"] > button'
    ).click(); // First deletion.
    cy.get(
      ':nth-child(1) > [style="padding: 12px 10px 12px 12px;"] > button'
    ).click(); // Second deletion.
    cy.get(
      ':nth-child(1) > [style="padding: 12px 10px 12px 12px;"] > button'
    ).click(); // Third deletion.

    // Purpose: Ensure cart updates correctly and all selected items are removed.
  });
});
