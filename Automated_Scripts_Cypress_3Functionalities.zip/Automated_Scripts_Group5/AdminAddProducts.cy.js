// Test case: Seller add product functionality
// This test validates the workflow for a seller to log in and add a new product to their inventory, including filling out product details and submitting the form.

describe("template spec", () => {
  it("passes", () => {
    // Step 1: Navigate to the homepage of the application.
    // Purpose: Start the test from the application's base URL to ensure consistency.
    cy.visit("http://localhost:3000/");

    // Step 2: Navigate to the seller panel or admin section.
    // Purpose: Simulate the seller accessing their dedicated dashboard from the homepage.
    cy.get(".home-container > a").click();

    // Step 3: Visit the seller registration page directly.
    // Purpose: Simulate registering a new seller account. This step ensures new sellers can sign up.
    cy.visit("http://localhost:3000/admin/registers");

    // Step 4: Fill in the registration form fields with seller details.
    // Purpose: Validate that the seller registration process works correctly.
    cy.get(":nth-child(1) > input").clear("A"); // Clear and type the seller's name.
    cy.get(":nth-child(1) > input").type("Amna");
    cy.get(":nth-child(2) > input").clear("i"); // Clear and type the email address.
    cy.get(":nth-child(2) > input").type("i221529@gmail.com");
    cy.get(":nth-child(3) > input").clear("1"); // Clear and type the password.
    cy.get(":nth-child(3) > input").type("1234");
    cy.get(":nth-child(4) > input").clear("x"); // Clear and type the business name.
    cy.get(":nth-child(4) > input").type("xyz");
    cy.get(":nth-child(5) > input").clear("1"); // Clear and type the seller's phone number.
    cy.get(":nth-child(5) > input").type("111111111111");

    // Submit the registration form.
    cy.get("form > button").click();

    // Step 5: Simulate seller login after registration.
    // Purpose: Log in as the newly registered seller to access their dashboard.
    cy.visit("http://localhost:3000/admin/registers");
    cy.get(
      '[style="border: white; background-color: white;"] > .nav-link'
    ).click();
    cy.get(":nth-child(1) > input").clear("i221529@gmail.com"); // Enter the registered email.
    cy.get(":nth-child(1) > input").type("i221529@gmail.com");
    cy.get(":nth-child(2) > input").clear("1"); // Enter the registered password.
    cy.get(":nth-child(2) > input").type("1234");
    cy.get("form > button").click();

    // Step 6: Navigate to the add product page.
    // Purpose: Access the page where the seller can add new products to their inventory.
    cy.get(":nth-child(2) > a").click();

    // Step 7: Fill in the product details form.
    // Purpose: Simulate a seller adding a new product with all required attributes.

    // Click the button to open the product form.
    cy.get(
      '[style="display: flex; justify-content: space-between; margin-bottom: 20px;"] > button'
    ).click();

    // Fill in the product ID.
    cy.get('[name="id"]').clear("8");
    cy.get('[name="id"]').type("876543");

    // Fill in the product name.
    cy.get('[name="name"]').clear("I");
    cy.get('[name="name"]').type("IPHONE 12 PRO MAX");

    // Fill in the product price.
    cy.get('[name="price"]').clear("1");
    cy.get('[name="price"]').type("1000000");

    // Upload a product image (this simulates a file upload, but may require configuration).
    cy.get('[type="file"]').click();

    // Select the product category from the dropdown.
    cy.get('[name="category"]').select("Tools & Hardware");

    // Select the product type.
    cy.get('[name="type"]').select("international");

    // Fill in product size details.
    cy.get('[name="sizes"]').click();
    cy.get('[name="sizes"]').clear("a");
    cy.get('[name="sizes"]').type("large");

    // Fill in product color details.
    cy.get('[name="colors"]').clear("g");
    cy.get('[name="colors"]').type("golden");

    // Fill in the product quantity available.
    cy.get('[name="quantity"]').clear("6");
    cy.get('[name="quantity"]').type("6");

    // Add additional product details in the text area (if applicable).
    cy.get("textarea").click();

    // Mark the product as "latest" and "featured" by checking respective boxes.
    cy.get("#latest").check();
    cy.get("#featured").check();

    // Submit the product form to add the product to the inventory.
    cy.get("form > button").click();

    // Step 8: Navigate to another section (e.g., orders or analytics) to validate navigation.
    // Purpose: Ensure the seller dashboard navigation works after adding a product.
    cy.get(":nth-child(3) > a").click();
  });
});
